package tests;
import java.util.Scanner;

public class AreaOfRectangle {
	public static void main(String[] args) {
		
		System.out.println("Bem-vindo!\nQual é o comprimento? ->");
		
		Scanner scanner = new Scanner(System.in);
		
		int len = scanner.nextInt();
		
		if(len > 0) { 
			System.out.println("E qual é a largura? ->");
			
		} else {
			System.out.println("Insere um número inteiro maior que 0? ->");
			}
		
	
	    int wid = scanner.nextInt();
	    
	    int area = len * wid;
	    
	    System.out.println("Perfeito, a área do teu retângulo é " + area + "m2." );
	
	}
	
}
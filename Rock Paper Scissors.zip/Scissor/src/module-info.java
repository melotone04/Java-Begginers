/**
 * 
 */
/**
 * 
 */
module Scissor {
}
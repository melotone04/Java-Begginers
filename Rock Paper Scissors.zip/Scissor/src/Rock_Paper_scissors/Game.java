package Rock_Paper_scissors;

import java.lang.Math;
import java.util.Scanner;

public class Game {
	
	public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Rock, Paper or Scissors, which will it be: ");
		String gameWord = scanner.nextLine();
		
		gameDecider(gameWord);
		
		scanner.close();
		
	}
	
	public static void gameDecider(String gameWord) {
		
		String[] gameOutput = {"Rock", "Paper", "Scissors"};
		
		int game = (int) Math.floor(Math.random() * 3);
		String computerChoice = gameOutput[game];
		
		System.out.println("Computer chose: " + computerChoice);
		
		if(gameWord.equalsIgnoreCase(computerChoice)) {
			
			System.out.println("It's a tie!");
			
		} else if ((gameWord.equalsIgnoreCase("Rock") && computerChoice.equals("Scissors")) ||
                (gameWord.equalsIgnoreCase("Paper") && computerChoice.equals("Rock")) ||
                (gameWord.equalsIgnoreCase("Scissors") && computerChoice.equals("Paper"))) {
			
			System.out.println("You win!");
			
		} else {
			
			System.out.println("You lose!");
			
		}
		
	}
	
}

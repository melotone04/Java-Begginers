package LearningJava;

import java.util.Scanner;

public class Java {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Insere uma palavra: ");
		String wordOne = scanner.nextLine();
		
		System.out.println("Insere outra palavra: ");
		String wordTwo = scanner.nextLine();
		
		ifFunc(wordOne, wordTwo);
		
		scanner.close();
		
	}
	
	public static void ifFunc(String wordOne, String wordTwo) {
		
		int wordOneLength = wordOne.length();
		int wordTwoLength = wordTwo.length();
		
		if(wordOneLength < wordTwoLength) {
			System.out.println("A palavra " + wordTwo + " é mais longa que a palavra " + wordOne + ".");
			
		} else if(wordOneLength == wordTwoLength) {
			System.out.println("As duas palavras são ingualmente longas.");
			System.out.println("Primeira palavra: " + wordOne);
			System.out.println("Segunda palavra: " + wordTwo);
		} else {
			System.out.println("A palavra " + wordOne + " é mais longa que a palavra " + wordTwo + ".");
		}
		
	}
	
}

